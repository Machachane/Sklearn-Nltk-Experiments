# sklearn-nltk-classification
 Text classification using sklearn and nltk
